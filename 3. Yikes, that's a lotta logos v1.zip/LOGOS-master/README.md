# Logos

DON'T BOTHER CONTRIBUTING TO THIS REPOSITORY. I will not be merging any contributions, as it would unlink files I use every day. Do let me know if you have a way of turning that off! THIS is totally useless; it only lasts 1 day: https://help.github.com/en/github/building-a-strong-community/limiting-interactions-in-your-repository

A collection of mostly tech-related logos that I (Taran Van Hemert) have collected over the last few years of video production. Some of them were remarkably difficult to find in a high enough quality. `.SVGs` are cool and all, but Premiere Pro cannot handle them. So these are almost entirely `.pngs` with transparent backgrounds.

## Usage

All logos belong to their respective brands. Please research the brand's guidelines on using its logo. (If you care about that sort of thing.)
